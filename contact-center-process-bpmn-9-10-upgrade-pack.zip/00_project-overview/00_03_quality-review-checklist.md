# Quality Review Checklist — Contact Center Portfolio Project

## Cel

Lista kontrolna pokazuje, co zostało dodane lub poprawione, aby projekt wyglądał jak profesjonalne case study przygotowane pod dużą organizację.

---

## Checklist

| Obszar | Kryterium | Status |
|---|---|---|
| Repo hygiene | Brak spacji na początku nazw plików | Do wdrożenia lokalnie |
| Repo hygiene | Pliki Markdown są sformatowane i czytelne w diffach | Gotowe w paczce |
| BPMN | Diagramy mają opis decyzji modelowania | Gotowe w paczce |
| BPMN | Pliki źródłowe `.bpmn` są przechowywane poza ZIP | Do wdrożenia lokalnie |
| SQL | Schemat zawiera `callbacks` i `sla_events` | Gotowe w paczce |
| SQL | Schemat zawiera constraints i indeksy raportowe | Gotowe w paczce |
| SQL | Dane przykładowe są syntetyczne i spójne z modelem | Gotowe w paczce |
| KPI | Zapytania KPI są sformatowane i kompletne | Gotowe w paczce |
| API | Dodano `openapi.yaml` | Gotowe w paczce |
| API | Dodano idempotencję, OAuth2, correlation id i standard błędów | Gotowe w paczce |
| Power BI | Miary DAX są wyeksportowane jako pliki tekstowe | Gotowe w paczce |
| Power BI | Opisano relacje modelu semantycznego | Gotowe w paczce |
| Governance | Dodano security / data governance | Gotowe w paczce |
| Traceability | Dodano macierz end-to-end | Gotowe w paczce |

---

## Rekomendacja przed commitem

1. Wypakuj paczkę do katalogu repozytorium.
2. Usuń plik ze spacją w nazwie: `01_business-analysis/ 01_04_user-stories.md`, jeżeli nadal istnieje.
3. Rozpakuj pliki `.bpmn.zip` i trzymaj w repo również pliki `.bpmn`.
4. Uruchom SQL w kolejności:
   - `04_01_database-schema.sql`
   - `04_02_sample-data.sql`
   - `04_03_kpi-queries.sql`
5. Otwórz Power BI i przenieś miary z folderu `dax/` do modelu.
6. Zrób commit opisowy, np. `upgrade enterprise readiness artifacts`.
