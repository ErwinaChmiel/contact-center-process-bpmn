# Traceability Matrix — Contact Center Process Optimization

## Cel

Macierz śledzenia pokazuje pełne powiązanie między problemem biznesowym, wymaganiami, User Stories, kryteriami akceptacji, procesem BPMN, API, modelem danych, KPI i dashboardem Power BI.

---

## End-to-end traceability

| Problem | Wymaganie | User Story | Kryterium akceptacji | BPMN TO-BE | API | Tabela SQL | KPI | Power BI |
|---|---|---|---|---|---|---|---|---|
| PB.01 Wysokie porzucenia | WB.01, WF.01, WF.04 | US.01, US.04, US.12 | AC.02, AC.04 | Callback zamiast oczekiwania w kolejce | `POST /callbacks` | `calls`, `callbacks` | Abandonment Rate, Callback Rate | Call Flow, Callback Performance |
| PB.02 Długi czas oczekiwania | WB.02, WF.01, WF.08 | US.01, US.11 | AC.04 | Monitorowanie kolejki i czasu oczekiwania | `POST /calls`, `GET /kpis/operational-summary` | `calls` | ASA, AHT | Executive Overview, Queue Performance |
| PB.03 Ograniczony self-service | WB.03, WF.03 | US.03 | AC.03 | Self-service w IVR | `POST /calls` | `calls`, `cases` | Self-service Rate, Contact Category Analysis | Contact Category Analysis |
| PB.04 Brak tagowania powodów kontaktu | WB.04, WF.03, WF.07 | US.03 | AC.03 | Tagowanie przyczyny kontaktu | `PATCH /cases/{caseId}/status` | `cases`, `contacts` | FCR, Category Volume | Category Analysis, Agent Performance |
| PB.05 Ograniczony monitoring KPI | WB.05, WF.07, WF.08 | US.10, US.11, US.13 | AC.04 | Dane do raportowania KPI | `GET /kpis/operational-summary` | Wszystkie tabele faktów | SLA, FCR, ASA, AHT, Callback | Executive Overview |
| PB.05 Brak alertów SLA | WB.05, WF.06, WF.07 | US.07, US.08, US.09 | AC.05 | Timer SLA i eskalacja | `PATCH /cases/{caseId}/status` | `cases`, `sla_events` | SLA Rate, Cases Past SLA, Escalation Rate | SLA & Case Management, Alerts |

---

## Traceability dla KPI

| KPI | Definicja | Źródło danych | Wymagania | User Stories | Dashboard page |
|---|---|---|---|---|---|
| ASA | Średni czas od wejścia do kolejki do odpowiedzi konsultanta | `calls.queue_start_time`, `calls.answer_time` | WF.01, WF.08 | US.01, US.11 | Queue Performance |
| AHT | Średni czas obsługi po odebraniu połączenia | `calls.answer_time`, `calls.end_time` | WF.01, WF.08 | US.11, US.13 | Agent Performance |
| FCR | Odsetek spraw rozwiązanych przy pierwszym kontakcie | `cases.resolution_type` | WF.02, WF.07, WF.08 | US.02, US.10 | Executive Overview |
| SLA Rate | Odsetek spraw zamkniętych w SLA | `cases.resolved_in_sla`, `sla_events` | WF.06, WF.07, WF.08 | US.07, US.09 | SLA & Case Management |
| Abandonment Rate | Odsetek połączeń porzuconych w kolejce | `calls.is_abandoned_in_queue` | WF.01, WF.04 | US.01, US.12 | Call Flow |
| Self-service Rate | Odsetek spraw obsłużonych automatycznie | `calls.is_self_service` | WF.03, WF.07 | US.03 | Contact Category Analysis |
| Callback Rate | Udział kolejkowanych połączeń z callbackiem | `callbacks`, `calls.queue_start_time` | WF.04, WF.05 | US.04, US.06 | Callback Performance |
| Callback Realization Rate | Udział callbacków zrealizowanych | `callbacks.status` | WF.05, WF.07 | US.05, US.06 | Callback Performance, Alerts |
| Escalation Rate | Udział spraw przekazanych do 2nd line | `cases.is_escalated_to_2nd_line` | WF.06, WF.07 | US.08 | SLA & Case Management |

---

## Wartość dla oceny projektu

Ta macierz zwiększa wiarygodność projektu, ponieważ pokazuje, że każdy element techniczny ma uzasadnienie biznesowe, a każdy KPI jest powiązany z wymaganiami, procesem i danymi.
