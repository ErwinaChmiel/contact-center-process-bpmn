# Patch apply commands

Ta paczka zawiera tylko pliki do podmiany / dodania w aktualnym repo `contact-center-process`.

## Pliki w paczce

```text
README.md
02_process-analysis/02_01_bpmn-as-is.bpmn
02_process-analysis/02_03_bpmn-to-be.bpmn
03_solution-architecture/03_03_api-specification.md
03_solution-architecture/03_04_openapi.yaml
06_documentation/06_04_run-instructions.md
```

## Co zrobić po skopiowaniu plików

Po rozpakowaniu paczki do katalogu repozytorium usuń stare duble BPMN:

```bash
git rm 02_process-analysis/02_01.1_bpmn-as-is.bpmn
git rm 02_process-analysis/02_03.1_bpmn-to-be.bpmn
git rm 02_process-analysis/02_01_bpmn-as-is.bpmn.zip
git rm 02_process-analysis/02_03_bpmn-to-be.bpmn.zip
```

Następnie dodaj pliki z patcha:

```bash
git add README.md \
  02_process-analysis/02_01_bpmn-as-is.bpmn \
  02_process-analysis/02_03_bpmn-to-be.bpmn \
  03_solution-architecture/03_03_api-specification.md \
  03_solution-architecture/03_04_openapi.yaml \
  06_documentation/06_04_run-instructions.md
```

Commit:

```bash
git commit -m "Clean up final repo structure and align API/BPMN documentation"
git push
```

## Efekt

- README nie ma już uciętego `TO-BE`.
- Root repo w README to `contact-center-process/`, nie stara nazwa.
- BPMN ma docelowe nazwy bez `.1` i bez ZIP-ów.
- API używa `cases`, nie `tickets`.
- Run instructions wskazują aktualne pliki i aktualną nazwę repo.
