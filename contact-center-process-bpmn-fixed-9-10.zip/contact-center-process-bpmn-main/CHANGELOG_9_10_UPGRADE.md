# Changelog — 9/10 Upgrade Pack

## Dodane

- `03_solution-architecture/openapi.yaml` — formalny kontrakt REST API.
- `03_solution-architecture/03_04_api-governance-notes.md` — standardy API enterprise.
- `05_power-bi-dashboard/dax/` — eksport miar DAX z podziałem na obszary.
- `05_power-bi-dashboard/semantic-model/` — relacje i katalog miar.
- `06_documentation/06_02_traceability-matrix.md` — macierz traceability end-to-end.
- `06_documentation/06_05_security-and-data-governance.md` — bezpieczeństwo, RODO/GDPR, RBAC i retencja.
- `02_process-analysis/02_07_bpmn-modeling-decisions.md` — decyzje modelowania BPMN.
- `00_project-overview/00_03_quality-review-checklist.md` — checklist jakości projektu.

## Zmienione

- `01_business-analysis/01_04_user-stories.md` — poprawiona nazwa pliku i formatowanie.
- `04_data-model/04_01_database-schema.sql` — dodano `callbacks`, `sla_events`, constraints i indeksy.
- `04_data-model/04_02_sample-data.sql` — dodano syntetyczne dane spójne z nowym schematem.
- `04_data-model/04_03_kpi-queries.sql` — dodano KPI dla callbacków, SLA, eskalacji, alertów i performance per agent.
- `04_data-model/04_04_data-model-description.md` — zsynchronizowano opis modelu z faktycznym SQL.

## Do wykonania ręcznie po wypakowaniu

- Usuń stary plik `01_business-analysis/ 01_04_user-stories.md`, jeżeli istnieje.
- Rozpakuj pliki `.bpmn.zip` do `.bpmn`, jeżeli w repo nadal są tylko paczki ZIP.
- Zaktualizuj PBIX miarami z folderu `05_power-bi-dashboard/dax/`.
