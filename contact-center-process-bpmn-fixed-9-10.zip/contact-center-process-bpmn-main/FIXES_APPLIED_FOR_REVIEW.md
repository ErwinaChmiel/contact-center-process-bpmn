# Fixes applied for repository review

This package was prepared as a corrected version of the repository after review.

## Critical fixes

1. **BPMN source files unpacked**
   - Replaced `02_01_bpmn-as-is.bpmn.zip` with `02_01_bpmn-as-is.bpmn`.
   - Replaced `02_03_bpmn-to-be.bpmn.zip` with `02_03_bpmn-to-be.bpmn`.
   - This makes the process models directly reviewable in BPMN tools.

2. **Dashboard preview repaired**
   - Replaced the broken 1-byte `05_02_dashboard-overview.png` with a valid PNG preview.
   - The preview is a static synthetic view for repository documentation. For a final portfolio release, replace it with a real screenshot exported from the PBIX file.

3. **OpenAPI aligned with SQL model**
   - Replaced ticket-oriented API naming with case-oriented naming.
   - Added `/api/v1/cases/{caseId}/status`.
   - Aligned identifiers with SQL integer IDs.
   - Aligned enums with SQL values for `channel`, `segment`, `status`, `priority`, `callback.status` and `sla_events.event_type`.
   - Added `X-Correlation-Id`, `Idempotency-Key` and JWT bearer security.

4. **Power BI review layer added**
   - Added DAX measure exports under `05_power-bi-dashboard/dax/`.
   - Added semantic model documentation under `05_power-bi-dashboard/semantic-model/`.

5. **README and run instructions synchronized**
   - Updated repository tree.
   - Removed references to missing `05_03_dashboard-data-model.png`.
   - Added references to BPMN modeling decisions, API governance, DAX, semantic model and security/data governance.
   - Replaced duplicated plain image paths with proper Markdown image previews.

## Files added or materially changed

- `README.md`
- `02_process-analysis/02_01_bpmn-as-is.bpmn`
- `02_process-analysis/02_03_bpmn-to-be.bpmn`
- `03_solution-architecture/03_04_openapi.yaml`
- `03_solution-architecture/03_05_api-governance-notes.md`
- `05_power-bi-dashboard/05_02_dashboard-overview.png`
- `05_power-bi-dashboard/dax/measures_calls.dax`
- `05_power-bi-dashboard/dax/measures_cases.dax`
- `05_power-bi-dashboard/dax/measures_callbacks.dax`
- `05_power-bi-dashboard/dax/measures_alerts.dax`
- `05_power-bi-dashboard/semantic-model/relationships.md`
- `05_power-bi-dashboard/semantic-model/measures-catalog.md`
- `06_documentation/06_04_run-instructions.md`
- `06_documentation/06_02_glossary.md`
- `00_project-overview/00_03_scope-and-assumptions.md`

## Recommended final manual action

Before publishing the repository as a final portfolio artifact, export a real screenshot from Power BI Desktop and replace:

```text
05_power-bi-dashboard/05_02_dashboard-overview.png
```

The current file is valid and review-safe, but it is a generated synthetic preview rather than a direct PBIX export.
