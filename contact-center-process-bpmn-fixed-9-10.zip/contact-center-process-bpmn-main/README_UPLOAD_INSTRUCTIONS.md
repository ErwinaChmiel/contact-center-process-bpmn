# Instrukcja wrzucenia paczki do GitHub

## Wariant A — przez lokalne repozytorium

1. Pobierz ZIP z paczką.
2. Wypakuj zawartość ZIP bezpośrednio do katalogu lokalnego repozytorium `contact-center-process-bpmn`.
3. Pozwól nadpisać istniejące pliki.
4. Usuń stary plik z błędną nazwą, jeżeli nadal istnieje:

```bash
rm "01_business-analysis/ 01_04_user-stories.md"
```

5. Sprawdź zmiany:

```bash
git status
git diff --stat
```

6. Dodaj i zatwierdź zmiany:

```bash
git add .
git commit -m "Upgrade project to enterprise-ready contact center case study"
git push
```

## Wariant B — przez GitHub web UI

1. Wejdź do repozytorium na GitHub.
2. Dla każdego pliku z paczki wybierz `Add file` / `Upload files` albo edytuj istniejący plik.
3. Zachowaj strukturę folderów z paczki.
4. Usuń stary plik `01_business-analysis/ 01_04_user-stories.md`, jeżeli GitHub nadal go pokazuje.
5. Dodaj commit message:

```text
Upgrade project to enterprise-ready contact center case study
```

## Kolejność uruchomienia SQL

```text
04_data-model/04_01_database-schema.sql
04_data-model/04_02_sample-data.sql
04_data-model/04_03_kpi-queries.sql
```

## Uwaga o Power BI

Pliki `.dax` nie aktualizują automatycznie pliku `.pbix`. Trzeba ręcznie dodać miary do Power BI Desktop albo użyć narzędzia typu Tabular Editor.
