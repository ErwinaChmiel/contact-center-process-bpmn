# Cleanup helper for Windows PowerShell
# Run from repository root after extracting the upgrade pack.

$badUserStoryPath = "01_business-analysis/ 01_04_user-stories.md"
if (Test-Path $badUserStoryPath) {
    Remove-Item $badUserStoryPath
    Write-Host "Removed old file with leading space: $badUserStoryPath"
}

Get-ChildItem "02_process-analysis" -Filter "*.bpmn.zip" -ErrorAction SilentlyContinue | ForEach-Object {
    Write-Host "BPMN ZIP found: $($_.FullName)"
    Write-Host "Recommended: extract it and commit the .bpmn source file next to the PNG preview."
}

Write-Host "Cleanup completed. Run: git status"
