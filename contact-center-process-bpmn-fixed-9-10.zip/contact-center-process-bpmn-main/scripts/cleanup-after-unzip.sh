#!/usr/bin/env bash
set -euo pipefail

# Run from repository root after extracting the upgrade pack.

BAD_USER_STORY_PATH="01_business-analysis/ 01_04_user-stories.md"
if [ -f "$BAD_USER_STORY_PATH" ]; then
  rm "$BAD_USER_STORY_PATH"
  echo "Removed old file with leading space: $BAD_USER_STORY_PATH"
fi

if compgen -G "02_process-analysis/*.bpmn.zip" > /dev/null; then
  echo "BPMN ZIP files found in 02_process-analysis/."
  echo "Recommended: extract them and commit the .bpmn source files next to the PNG previews."
fi

echo "Cleanup completed. Run: git status"
