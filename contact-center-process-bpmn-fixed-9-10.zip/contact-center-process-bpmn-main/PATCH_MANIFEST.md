# Patch Manifest — Contact Center 9/10 Upgrade Pack

Generated package contents:

```text
00_project-overview/00_03_quality-review-checklist.md
01_business-analysis/01_04_user-stories.md
02_process-analysis/02_07_bpmn-modeling-decisions.md
03_solution-architecture/03_04_api-governance-notes.md
03_solution-architecture/openapi.yaml
04_data-model/04_01_database-schema.sql
04_data-model/04_02_sample-data.sql
04_data-model/04_03_kpi-queries.sql
04_data-model/04_04_data-model-description.md
05_power-bi-dashboard/dax/measures_alerts.dax
05_power-bi-dashboard/dax/measures_callbacks.dax
05_power-bi-dashboard/dax/measures_calls.dax
05_power-bi-dashboard/dax/measures_cases.dax
05_power-bi-dashboard/semantic-model/measures-catalog.md
05_power-bi-dashboard/semantic-model/relationships.md
06_documentation/06_02_traceability-matrix.md
06_documentation/06_05_security-and-data-governance.md
CHANGELOG_9_10_UPGRADE.md
README_UPLOAD_INSTRUCTIONS.md
scripts/cleanup-after-unzip.ps1
scripts/cleanup-after-unzip.sh
```

## Scope

This package is a drop-in upgrade pack. It contains changed and added files only, not the binary PBIX or BPMN/PNG assets from the original repository.

## Main improvements

- SQL schema now contains explicit `callbacks` and `sla_events` tables.
- KPI SQL is formatted and extended.
- DAX measures are exported to text files.
- OpenAPI contract is provided as `openapi.yaml`.
- Traceability, security/governance and BPMN modeling decisions are documented.
- User Stories file is provided with corrected filename and professional Markdown formatting.
